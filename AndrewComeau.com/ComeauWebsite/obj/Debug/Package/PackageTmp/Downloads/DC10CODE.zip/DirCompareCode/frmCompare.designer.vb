<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCompare
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCompare))
        Me.txtPrimary = New System.Windows.Forms.TextBox
        Me.txtComparison = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.btnCompare = New System.Windows.Forms.Button
        Me.rtbOutput = New System.Windows.Forms.RichTextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.btnClear = New System.Windows.Forms.Button
        Me.btnPrimary = New System.Windows.Forms.Button
        Me.btnSecondary = New System.Windows.Forms.Button
        Me.folderDialog = New System.Windows.Forms.FolderBrowserDialog
        Me.mainMenu = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CompareToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveOutputToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Label1 = New System.Windows.Forms.Label
        Me.mainStatus = New System.Windows.Forms.StatusStrip
        Me.statusMessage = New System.Windows.Forms.ToolStripStatusLabel
        Me.toolTips = New System.Windows.Forms.ToolTip(Me.components)
        Me.errorDisplay = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.btnSave = New System.Windows.Forms.Button
        Me.SaveDialog = New System.Windows.Forms.SaveFileDialog
        Me.mainMenu.SuspendLayout()
        Me.mainStatus.SuspendLayout()
        CType(Me.errorDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtPrimary
        '
        Me.txtPrimary.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPrimary.Location = New System.Drawing.Point(15, 88)
        Me.txtPrimary.Name = "txtPrimary"
        Me.txtPrimary.Size = New System.Drawing.Size(479, 20)
        Me.txtPrimary.TabIndex = 0
        Me.toolTips.SetToolTip(Me.txtPrimary, "This directory contains the master set of files and subfolders.")
        '
        'txtComparison
        '
        Me.txtComparison.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtComparison.Location = New System.Drawing.Point(15, 144)
        Me.txtComparison.Name = "txtComparison"
        Me.txtComparison.Size = New System.Drawing.Size(479, 20)
        Me.txtComparison.TabIndex = 1
        Me.toolTips.SetToolTip(Me.txtComparison, "Files and subfolders under this directory will be compared to those in the primar" & _
                "y directory.")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Primary directory:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 128)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Secondary directory:"
        '
        'btnCompare
        '
        Me.btnCompare.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCompare.Location = New System.Drawing.Point(465, 180)
        Me.btnCompare.Name = "btnCompare"
        Me.btnCompare.Size = New System.Drawing.Size(75, 23)
        Me.btnCompare.TabIndex = 5
        Me.btnCompare.Text = "Compare"
        Me.toolTips.SetToolTip(Me.btnCompare, "Compare the two directory structures.")
        Me.btnCompare.UseVisualStyleBackColor = True
        '
        'rtbOutput
        '
        Me.rtbOutput.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rtbOutput.Location = New System.Drawing.Point(12, 209)
        Me.rtbOutput.Name = "rtbOutput"
        Me.rtbOutput.ReadOnly = True
        Me.rtbOutput.Size = New System.Drawing.Size(529, 151)
        Me.rtbOutput.TabIndex = 6
        Me.rtbOutput.Text = ""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(15, 194)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Results:"
        '
        'btnClear
        '
        Me.btnClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClear.Location = New System.Drawing.Point(465, 366)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.toolTips.SetToolTip(Me.btnClear, "Clear the output field.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnPrimary
        '
        Me.btnPrimary.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrimary.Location = New System.Drawing.Point(512, 88)
        Me.btnPrimary.Name = "btnPrimary"
        Me.btnPrimary.Size = New System.Drawing.Size(28, 20)
        Me.btnPrimary.TabIndex = 9
        Me.btnPrimary.Text = "..."
        Me.toolTips.SetToolTip(Me.btnPrimary, "Click to select directory.")
        Me.btnPrimary.UseVisualStyleBackColor = True
        '
        'btnSecondary
        '
        Me.btnSecondary.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSecondary.Location = New System.Drawing.Point(513, 144)
        Me.btnSecondary.Name = "btnSecondary"
        Me.btnSecondary.Size = New System.Drawing.Size(28, 20)
        Me.btnSecondary.TabIndex = 10
        Me.btnSecondary.Text = "..."
        Me.toolTips.SetToolTip(Me.btnSecondary, "Click to select directory.")
        Me.btnSecondary.UseVisualStyleBackColor = True
        '
        'mainMenu
        '
        Me.mainMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.mainMenu.Location = New System.Drawing.Point(0, 0)
        Me.mainMenu.Name = "mainMenu"
        Me.mainMenu.Size = New System.Drawing.Size(553, 24)
        Me.mainMenu.TabIndex = 12
        Me.mainMenu.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CompareToolStripMenuItem, Me.SaveOutputToolStripMenuItem, Me.ClearToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'CompareToolStripMenuItem
        '
        Me.CompareToolStripMenuItem.Name = "CompareToolStripMenuItem"
        Me.CompareToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CompareToolStripMenuItem.Text = "&Compare"
        '
        'SaveOutputToolStripMenuItem
        '
        Me.SaveOutputToolStripMenuItem.Name = "SaveOutputToolStripMenuItem"
        Me.SaveOutputToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SaveOutputToolStripMenuItem.Text = "&Save Output"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ClearToolStripMenuItem.Text = "C&lear Output"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(149, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.Location = New System.Drawing.Point(13, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(528, 30)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Enter the two directories to be compared in the fields below and click the Compar" & _
            "e button to begin the comparison."
        '
        'mainStatus
        '
        Me.mainStatus.BackColor = System.Drawing.SystemColors.Control
        Me.mainStatus.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.statusMessage})
        Me.mainStatus.Location = New System.Drawing.Point(0, 404)
        Me.mainStatus.Name = "mainStatus"
        Me.mainStatus.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.mainStatus.Size = New System.Drawing.Size(553, 22)
        Me.mainStatus.TabIndex = 14
        '
        'statusMessage
        '
        Me.statusMessage.Name = "statusMessage"
        Me.statusMessage.Size = New System.Drawing.Size(538, 17)
        Me.statusMessage.Spring = True
        Me.statusMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'errorDisplay
        '
        Me.errorDisplay.ContainerControl = Me
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.Location = New System.Drawing.Point(12, 366)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(87, 23)
        Me.btnSave.TabIndex = 15
        Me.btnSave.Text = "Save Results"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'SaveDialog
        '
        Me.SaveDialog.Filter = "Rich Text Files (*.rtf)|*.rtf"
        Me.SaveDialog.Title = "Save results to ..."
        '
        'frmCompare
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(553, 426)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.mainStatus)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSecondary)
        Me.Controls.Add(Me.btnPrimary)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.rtbOutput)
        Me.Controls.Add(Me.btnCompare)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtComparison)
        Me.Controls.Add(Me.txtPrimary)
        Me.Controls.Add(Me.mainMenu)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mainMenu
        Me.Name = "frmCompare"
        Me.Text = " Directory Comparison"
        Me.mainMenu.ResumeLayout(False)
        Me.mainMenu.PerformLayout()
        Me.mainStatus.ResumeLayout(False)
        Me.mainStatus.PerformLayout()
        CType(Me.errorDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtPrimary As System.Windows.Forms.TextBox
    Friend WithEvents txtComparison As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnCompare As System.Windows.Forms.Button
    Friend WithEvents rtbOutput As System.Windows.Forms.RichTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnPrimary As System.Windows.Forms.Button
    Friend WithEvents btnSecondary As System.Windows.Forms.Button
    Friend WithEvents folderDialog As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents mainMenu As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents mainStatus As System.Windows.Forms.StatusStrip
    Friend WithEvents statusMessage As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents CompareToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents toolTips As System.Windows.Forms.ToolTip
    Friend WithEvents errorDisplay As System.Windows.Forms.ErrorProvider
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents SaveDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents SaveOutputToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
