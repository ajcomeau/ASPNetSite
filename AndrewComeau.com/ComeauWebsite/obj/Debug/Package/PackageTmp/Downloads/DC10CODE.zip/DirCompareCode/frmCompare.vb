
Public Class frmCompare

    Private dirPrimary As String        'Primary directory
    Private dirCompare As String        'Comparison directory
    Private fileCount As Integer = 0    'Number of files processed.
    Private itemsFound As Boolean       'Tracks if discrepances were found for output window.

    Private Sub btnFolderSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrimary.Click, btnSecondary.Click

        'Show folder dialog for user to select directory.

        Dim btnPress As Button = CType(sender, Button)

        Try
            'Set description on folder dialog based on which field is being completed.
            If btnPress.Name = "btnPrimary" Then
                folderDialog.Description = "Select a folder and click OK to use it as the primary directory."
            Else
                folderDialog.Description = "Select a folder and click OK to use it as the comparison directory."
            End If

            'Insert result into appropriate field based on button clicked.
            If folderDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
                If btnPress.Name = "btnPrimary" Then
                    txtPrimary.Text = folderDialog.SelectedPath
                Else
                    txtComparison.Text = folderDialog.SelectedPath
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error ...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub

    Private Sub btnCompare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompare.Click, CompareToolStripMenuItem.Click

        Try
            'Clear any previous output.
            rtbOutput.Text = ""
            itemsFound = False

            'Validate the directories entered before proceeding.
            If ValidateInputs() Then
                dirPrimary = txtPrimary.Text
                dirCompare = txtComparison.Text
                'Reset filecount.
                fileCount = 0
                CompareDirectories(dirPrimary)
                'After comparison is finished, report.
                statusMessage.Text = fileCount.ToString & " files tested."
                If Not itemsFound And Len(rtbOutput.Text) = 0 Then
                    rtbOutput.Text &= "No discrepancies found."
                End If
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error ...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub

    Private Sub CompareDirectories(ByVal subDirectory As String)

        'Count the number of files and subdirectories under this folder.
        Dim noFiles As Integer = FileIO.FileSystem.GetFiles(subDirectory).Count
        Dim noFolders As Integer = FileIO.FileSystem.GetDirectories(subDirectory).Count
        Dim comparisonFile As String
        Dim fileNameOnly As String, altDirectory As String

        Try
            'If there are files, process each one.
            If noFiles > 0 Then
                For Each fileName As String In FileIO.FileSystem.GetFiles(subDirectory)
                    'Increment file count ...
                    fileCount += 1
                    'Determine file path / name of corresponding file ...
                    comparisonFile = dirCompare & fileName.Substring(Len(dirPrimary))
                    'If corresponding file does not exist, add the necessary information to the output field.
                    If Not FileIO.FileSystem.FileExists(comparisonFile) Then
                        fileNameOnly = FileIO.FileSystem.GetName(fileName)
                        altDirectory = comparisonFile.Substring(0, Len(comparisonFile) - Len(fileNameOnly))
                        rtbOutput.Text &= FileNotice(fileNameOnly, subDirectory, altDirectory)
                        itemsFound = True
                    End If
                Next
            End If

            'If there are subdirectories, display the name of each one in the status label
            'and read its subfolders.
            If noFolders > 0 Then
                For Each folderName As String In FileIO.FileSystem.GetDirectories(subDirectory)
                    statusMessage.Text = "Reading " & folderName
                    'Determine name of corresponding subfolder under the comparison directory.
                    altDirectory = dirCompare & folderName.Substring(Len(dirPrimary))
                    'Recursively check subdirectories if they exist.
                    If FileIO.FileSystem.DirectoryExists(altDirectory) Then
                        CompareDirectories(folderName)
                    Else
                        'If the corresponding directory does not exist, add the necessary information to the output field.
                        rtbOutput.Text &= DirectoryNotice(altDirectory, folderName)
                        itemsFound = True
                    End If
                Next
                Application.DoEvents()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error ...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub
    Private Function FileNotice(ByVal fileName As String, ByVal subDirectory As String, ByVal altDirectory As String) As String

        'Assemble text for addition to output box.
        FileNotice = "File Discrepancy: " & vbCrLf
        FileNotice &= fileName & vbCrLf
        FileNotice &= "Exists in " & subDirectory & vbCrLf
        FileNotice &= "Does not exist in " & altDirectory & vbCrLf & vbCrLf

    End Function

    Private Function DirectoryNotice(ByVal altDirectory As String, ByVal folderName As String) As String

        'Assemble text for addition to output box.
        DirectoryNotice = "Folder Discrepancy: " & vbCrLf
        DirectoryNotice &= altDirectory & " does not exist." & vbCrLf
        DirectoryNotice &= "This folder would correspond to the existing folder" & vbCrLf
        DirectoryNotice &= folderName & vbCrLf & "located within the primary directory." & vbCrLf & vbCrLf

    End Function

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click, ClearToolStripMenuItem.Click

        'Clear the output field and status bar.
        rtbOutput.Text = ""
        statusMessage.Text = ""

    End Sub
    
    
    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click

        'Close the form.
        Me.Close()

    End Sub

    Private Function ValidateInputs() As Boolean

        'Validate directory inputs.

        Dim primaryPass As Boolean = False, secondaryPass As Boolean = False

        Try
            'Assume false to start.

            ValidateInputs = False

            'Check for missing directory entries and directories that don't exist.

            'Primary directory

            If Len(txtPrimary.Text) = 0 Then
                errorDisplay.SetError(txtPrimary, "Please enter a directory.")
            ElseIf Not FileIO.FileSystem.DirectoryExists(txtPrimary.Text) Then
                errorDisplay.SetError(txtPrimary, "This directory does not exist. Please try again.")
            Else
                errorDisplay.SetError(txtPrimary, "")
                primaryPass = True
            End If

            'Secondary directory

            If Len(txtComparison.Text) = 0 Then
                errorDisplay.SetError(txtComparison, "Please enter a directory.")
            ElseIf Not FileIO.FileSystem.DirectoryExists(txtComparison.Text) Then
                errorDisplay.SetError(txtComparison, "This directory does not exist. Please try again.")
            Else
                errorDisplay.SetError(txtComparison, "")
                secondaryPass = True
            End If

            'If both fields have passed, then return true.
            If primaryPass And secondaryPass Then
                ValidateInputs = True
            End If
        Catch ex As Exception
            Throw New ApplicationException("Error while validating selected directories.", ex)
        End Try

    End Function


    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click, SaveOutputToolStripMenuItem.Click

        Try
            If SaveDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
                If SaveDialog.CheckPathExists Then
                    rtbOutput.SaveFile(SaveDialog.FileName, RichTextBoxStreamType.RichText)
                    statusMessage.Text = "File saved to " & SaveDialog.FileName & "."
                Else
                    MessageBox.Show("That location does not exist.  Please select a valid directory in which to save the file.", "Error saving file ...")
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error ...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub

End Class
